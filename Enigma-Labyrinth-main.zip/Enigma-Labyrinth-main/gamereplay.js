const replay = document.getElementById("replay")

replay.onclick = () => {
    location.href = "./game.html";
  };