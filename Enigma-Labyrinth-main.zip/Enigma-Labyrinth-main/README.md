# Enigma-Labyrinth

A simple game built with Vanilla HTML, CSS and Javascript.
