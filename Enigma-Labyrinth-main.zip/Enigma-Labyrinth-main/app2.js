document.addEventListener('click', function() {
    window.location.href = 'game.html';
  })